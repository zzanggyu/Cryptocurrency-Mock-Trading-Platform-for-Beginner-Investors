import { useEffect } from "react";
import { useRecoilState } from "recoil";
import styled from "styled-components";
import { useFetchMarketCode } from "use-upbit-api";
import { marketCodesState } from "./atom";
import CoinDetails from "./CoinDetails";
import CoinSelector from "./CoinSelector";
import Trading from "./Trading";

const DisplayBoard = styled.main`
  width: 100%;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1fr 3fr;
  background-color: whitesmoke;
  height: 180vh;

  font-family: Arial, Helvetica, sans-serif;

  *::-webkit-scrollbar,
  *::-webkit-scrollbar-thumb {
    width: 0px;
  }

  *::-webkit-scrollbar-thumb {
  }
  *:hover::-webkit-scrollbar,
  *:hover::-webkit-scrollbar-thumb {
    width: 26px;
    border-radius: 13px;
    background-clip: padding-box;
    border: 12px solid transparent;
    color: grey;
  }

  *:hover::-webkit-scrollbar-thumb {
    box-shadow: inset 0 0 0 10px;
  }

  box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
`;
function TotalExample() {
  const { isLoading, marketCodes: fetchedMC } = useFetchMarketCode();
  const [marketCodes, setMarketCodes] = useRecoilState(marketCodesState);

  useEffect(() => {
    const MarketCodes_KRW = fetchedMC.filter((code) =>
      code.market.includes("KRW")
    );
    setMarketCodes(MarketCodes_KRW);
  }, [fetchedMC]);

  return (
    <DisplayBoard>
      <CoinSelector />
      <CoinDetails />
    </DisplayBoard>
  );
}
export default TotalExample;
