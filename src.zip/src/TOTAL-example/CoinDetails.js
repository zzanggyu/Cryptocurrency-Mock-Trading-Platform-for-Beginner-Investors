import styled from "styled-components";
import RealTimeChart from "./RealTimeChart";
import CoinInfo from "./CoinInfo";
import RealTimeOrderBook from "./RealTimeOrderBook";
import RealTimeTradeHistory from "./RealTimeTradeHistory";
import Trading from "./Trading";

const DetailLayout = styled.div`
  height: 800px;
  background-color: whitesmoke;
  padding: 5px;
  display: grid;
  gap: 5px;
  grid-template-columns: 1fr 1fr 1.1fr;
  margin-left : 110px;
  width: 1360px;
`;

const OrderBookWrapper = styled.div`
  position: absolute;
  bottom: -390px;
  left: 10;
  width: 99%;
  height: 50px;
  background-color: whitesmoke;
  z-index: 1000;
  padding: 10px;
`;

function CoinDetails() {
  return (
    <>
      <DetailLayout>
        <CoinInfo />
        <RealTimeChart />
        <Trading />
        <RealTimeOrderBook />
      </DetailLayout>
      <OrderBookWrapper>
      <RealTimeTradeHistory /> 
      </OrderBookWrapper>
    </>
  );
}

export default CoinDetails;
