package com.crypto.trading.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FavoriteDTO {
	private String symbol;
	private String coinName;
}
