package com.crypto.trading.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StyleDTO {
	private String style;
	private int score;
}
