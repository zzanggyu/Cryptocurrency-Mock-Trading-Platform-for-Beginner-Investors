package com.crypto.trading.dto;

import java.beans.ConstructorProperties;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import com.crypto.trading.entity.News;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class NewsDTO {
    private Long id;
    private String title;
    private String content;
    private String url;
    private String imageUrl;
    private LocalDateTime publishDate;
    private String source;
    private String author;
    private Set<String> categories = new HashSet<>();
    private Set<String> keywords = new HashSet<>();
    private boolean isFavorited;
    
    @ConstructorProperties({"id", "title", "content", "url", "imageUrl", "publishDate", "source", "author", "categories", "keywords"})
    public NewsDTO(Long id, String title, String content, String url, String imageUrl,
                  LocalDateTime publishDate, String source, String author, 
                  Set<String> categories, Set<String> keywords) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.url = url;
        this.imageUrl = imageUrl;
        this.publishDate = publishDate;
        this.source = source;
        this.author = author;
        this.categories = categories;
        this.keywords = keywords;
    }

    public static NewsDTO from(News news) {
        return NewsDTO.builder()
                .id(news.getId())
                .title(news.getTitle())
                .content(news.getContent())
                .url(news.getUrl())
                .imageUrl(news.getImageUrl())
                .publishDate(news.getPublishDate())
                .source(news.getSource())
                .author(news.getAuthor())
                .categories(news.getCategories() != null ? news.getCategories() : new HashSet<>())
                .keywords(news.getKeywords() != null ? news.getKeywords() : new HashSet<>())
                .build();
    }

    public News toEntity() {
        News news = new News();
        news.setTitle(this.title);
        news.setContent(this.content);
        news.setUrl(this.url);
        news.setImageUrl(this.imageUrl);
        news.setPublishDate(this.publishDate);
        news.setSource(this.source);
        news.setAuthor(this.author);
        news.setCategories(this.categories);
        news.setKeywords(this.keywords);
        return news;
    }
}